var a=[4,7,9,2,6,5,3,5];
console.log(a);
function bulling(a)
{
  for(var i=0;i<a.length;i++)
  {
    for(var j=i+1;j<a.length;j++)
    {
     if(a[i]>a[j]){ 
         var t;
         t=a[i];
         a[i]=a[j];
         a[j]=t;
         }
    } 
  }
     console.log(a);
}
bulling(a);
